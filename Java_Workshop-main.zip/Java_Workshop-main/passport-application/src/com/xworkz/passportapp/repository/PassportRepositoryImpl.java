package com.xworkz.passportapp.repository;

import com.xworkz.passportapp.dto.PassportAppDetailsDto;

public class PassportRepositoryImpl  {





}
