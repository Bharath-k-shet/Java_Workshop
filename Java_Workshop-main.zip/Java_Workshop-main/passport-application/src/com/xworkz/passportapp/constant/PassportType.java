package com.xworkz.passportapp.constant;

public class PassportType {

}
