package in.edu.pestrust.things;

public class UserAddress {

        //static variables
        public static String city="shimoga";
        public static int pincode=577201;

}
