package in.edu.pestrust.things;

public class User {
    public static String  city;
    public static int pincode;
    public static byte countrycode;
    public static long phoneNumber;
    public static short ProductNumber;
    public static double WhatsappNumber;
    public static char Name;
    public static boolean  name;
    public static float price;





}
