package in.edu.pestrust.runner;

public class Userinformation {
    public static void main(String[] args) {
        System.out.println("User information details are!!!");
        //local variable
        String name="Prashanth";
        long ContactNumber =987654321;
        int aadharNumber =43218765;
        String email ="prashanthmshiralagi@gmail.com";
        System.out.println("User Name is:"+name);
        System.out.println("User ContactNumber is:"+ContactNumber);
        System.out.println("User aadharNumber is:"+aadharNumber);
        System.out.println("User email is:"+email);
    }
}
