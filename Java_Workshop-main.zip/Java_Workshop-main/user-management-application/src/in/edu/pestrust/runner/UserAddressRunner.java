package in.edu.pestrust.runner;
import in.edu.pestrust.things.UserAddress;
public class UserAddressRunner {
    public static void main(String[] args) {

        System.out.println(UserAddress.city);
        System.out.println(UserAddress.pincode);
    }
}
