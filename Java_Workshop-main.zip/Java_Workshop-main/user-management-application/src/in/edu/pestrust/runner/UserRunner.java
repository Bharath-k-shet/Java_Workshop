package in.edu.pestrust.runner;

import in.edu.pestrust.things.User;

public class UserRunner {
    public static void main(String[] args) {
        System.out.println(User.city);
        System.out.println(User.pincode);
        System.out.println(User.countrycode);
        System.out.println(User.phoneNumber);
        System.out.println(User.ProductNumber);
        System.out.println(User.WhatsappNumber);
        System.out.println(User.Name);
        System.out.println(User.name);
        System.out.println(User.price);

    }
}
