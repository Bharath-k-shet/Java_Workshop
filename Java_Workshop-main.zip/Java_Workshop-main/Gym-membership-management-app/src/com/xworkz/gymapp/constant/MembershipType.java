package com.xworkz.gymapp.constant;

public enum MembershipType {

    DAILY,WEEKLY,YEARLY
}
